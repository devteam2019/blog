<?php
class Database{

    // specify your own database credentials
    private $host = "sql157.main-hosting.eu.";
    private $db_name = "u436855858_blog";
    private $username = "u436855858_blog";
    private $password = "broadcast07";
    public $conn;

    // get the database connection
    public function getConnection(){

        $this->conn = null;

        try{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
        }catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
        }

        return $this->conn;
    }
}
?>
